.. scriptine documentation master file, created by
   sphinx-quickstart on Wed Jul 29 11:57:44 2009.

Welcome to scriptine's documentation!
=====================================



.. toctree::
   :maxdepth: 2
   
   intro
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

