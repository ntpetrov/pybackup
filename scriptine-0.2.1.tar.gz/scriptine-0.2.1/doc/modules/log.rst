:mod:`scriptine.log` -- simple logging for commands
===================================================

Module Contents
---------------

.. module:: scriptine.log

Calling shell commands
^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: mark
.. autofunction:: info

.. autofunction:: warn
.. autofunction:: error
.. autofunction:: fatal
.. autofunction:: debug

