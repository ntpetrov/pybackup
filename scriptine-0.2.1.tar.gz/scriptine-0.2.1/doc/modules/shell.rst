:mod:`scriptine.shell` -- call other shell commands
===================================================

Module Contents
---------------

.. module:: scriptine.shell

Calling shell commands
^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: call
.. autofunction:: sh

.. autofunction:: backtick
.. autofunction:: backtick_


